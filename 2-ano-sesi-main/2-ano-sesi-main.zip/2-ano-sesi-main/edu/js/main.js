function clickbotao(){
    console.log(botao)
    botao.className="texte-vermelho"
}
function clickbotao(){
   let botao=document.getElementById('titulo-texto')
   console.log(botao)
   botao.className="text-azul"

}
